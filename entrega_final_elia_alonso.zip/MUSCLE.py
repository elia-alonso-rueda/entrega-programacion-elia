#!/usr/bin/env python
# encoding: utf-8

import os
import sys
from subprocess import Popen, PIPE


#Alineamiento de los hits obtenidos a partir de BlastP.
def Align(archivo_alineamiento):
	#Con muscle alineamos todos los archivos de las querys que hemos obtenido en BLAST.py.
	proceso = Popen(['muscle','-in',archivo_alineamiento], stdout=PIPE, stderr=PIPE)
	listado = proceso.stdout.read().decode("utf-8")
	proceso.stdout.close()
	#Crear archivo en el que almacenar el alineamiento (f).
	my_output = open('f',"w")
	my_output.write(listado)
	my_output.close()
#Generar árboles a partir del alineamiento de los hits de cada query.
def Tree(archivo_tree):  
	#Con muscle-maketree creamos un árbol a partie del archivo alineado (f) y se almacena en un archivo con el nombre de la query y formato .tree.
	proceso = Popen(['muscle','-maketree','-in','f','-out',archivo_tree+".tree",'-cluster','neighborjoining'], stderr=PIPE)
	