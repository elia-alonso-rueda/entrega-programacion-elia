#!/usr/bin/env python
# encoding: utf-8

import os 
import sys
from subprocess import Popen, PIPE, call
from Bio import Seq
from Bio import SeqIO

#PARSEO DE LA BASE DE DATOS GENBANK PARA REALIZAR EL BLAST.
def Parseo_blast(archivo_parseo):
	try:
		subject = open("subject","w") #generar archivo para guardar el parseo
		with open(archivo_parseo, "r") as input_handle: #abrir base de datos del usuario
			for record in SeqIO.parse(input_handle, "genbank"):
				print()
			for feature in record.features:
				if feature.type == 'CDS':
					try: #Al recorrer la base de datos nos quedamos con la etiqueta del locus y la secuencia de la proteína
						locus = feature.qualifiers['locus_tag'][0]
						seq_prot = feature.qualifiers['translation'][0]
						resultado = str(">"+locus+"\n"+seq_prot+"\n")
						subject.write(resultado)
					except:
						pass
		#Cerrar el archivo subject que contiene todos los subjects de la base de datos: identificador y secuencia (proteína).
		subject.close()
	except: #Si no reconoce el archivo que ha introducido el usuario.
		print("Se ha producido un error. Compruebe que el formato de la base de datos es .gbff y que está en el directorio desde el que está ejecutando este programa.")		
		sys.exit()

#BLASTP DE LAS PROTEÍNAS QUERY CON EL ARCHIVO SUBJECT (PARSEADO).
def Blast(archivo_query):
	try: #Realizar BlastP con Popen.
		proceso = Popen(['blastp','-query', archivo_query, '-subject', 'subject','-outfmt',"6 qseqid sseqid qcovs pident evalue"], stdout=PIPE, stderr=PIPE)
		error_encontrado = proceso.stderr.read().decode("utf-8")
		proceso.stderr.close()
		#El resultado que vayamos obeniendo de realizar el blastp se almacenará en la variable listado.
		listado = proceso.stdout.read().decode("utf-8")
		proceso.stdout.close()
		#Se crea un archivo en el que almacenar los resultados del blastp y se completa con listado.
		my_output = open("blast_result","w")
		my_output.write(listado)
		#Si se detecta algún error se informa al usuario, si no, se muestra el resultado de blastp en pantalla para que el usuario pueda visualizarlo y filtrar.
		if not error_encontrado: 
		    print(listado) 
		else: #Se informa al usuario del error que se ha cometido
		    print("Se produjo el siguiente error:\n%s" % error_encontrado)
		    sys.exit()
	except: #Si no reconoce el archivo que ha introducido el usuario.
		print("Se ha producido un error. Compruebe que el formato del archivo es .fasta y que está en el directorio desde el que está ejecutando este programa.")
		sys.exit()

#FILTRAR RESULTADOS DE BLASTP CON VALORES DE INTERÉS PARA EL USUARIO
def Filtro():
	blast_result = "blast_result"
	print("FILTRADO DE LOS RESULTADOS DEL BLAST.\nEscoja los valores de cobertura, porcentaje de indentidad y e-value a partir de los cuales quiere filtrar.")
	#Pedir al usuario que introduzca los valores a partir de los cuales quiere filtrar.
	while True:
		try:
			cov=float(input("\tCobertura: "))
			break
		except:
			print("El valor de cobertura debe ser un número.")
	while True:
		try:
			ident=float(input("\tPorcentaje de identidad: "))
			break
		except:
			print("El valor de porcentaje de identidad debe ser un número.")
	while True:
		try:
			value=float(input("\te-value: "))
			break
		except:
			print("El valor de e-vaule debe ser un número.")
	call('clear')
	print("Los valores que ha escogido son los siguientes:\n\tCobertura: {}\n\tPorcentaje de identidad: {}\n\te-value: {}".format(cov,ident,value))

	filtrar = open('blast_result','r') #Abrir el archivo de resultados de blast
	filtrar = filtrar.read()
	
	list_of_lists = []
	for i in filtrar.split('\n'):
		lista = i.split('\t')
		if lista == ['']:
			pass
		else: #Crear una lista con la query y el subject que cumple los requisitos del filtro (query_subject) y añadirla a una lista que contendrá todas las querys con sus respectivas subjects (list_of_lists).
			if float(lista[2]) >= cov and float(lista[3]) >= ident and float(lista[4]) <= value:
				query_subject = [lista[0],lista[1]]
				list_of_lists.append(query_subject)

	queryID=[] #Generar una lista solo con los querys que cumplen los filtros para nombrar los archivos con el nombre de cada query.
	for i in range(len(list_of_lists)):
		if list_of_lists[i][0] in queryID:
			pass
		else:
			queryID.append(list_of_lists[i][0])
	
	for i in range(len(queryID)): #Recorrer la lista de querys y la que contiene querys y subjects para generar una lista de subjects con las posiciones correspondientes a la de querys.
		subjects = []
		for j in range(len(list_of_lists)):
			if queryID[i] == list_of_lists[j][0]:
				subjects.append(list_of_lists[j][1])

		# Crear archivo con el nombre de la query
		name = queryID[i]
		subjectsID = open(name,"w")
		# Abrir el archivo que hemos obtenido del parseo
		parseo_result = open('subject','r')
		parseo_result = parseo_result.read()
		#Crear lista donde meter el subject y su correspondiente secuencia para crear el archivo a partir de esa lista
		arc = []
		var = parseo_result.split('\n')
		for ID in range(len(subjects)):
			arc.append(">"+subjects[ID])
			for i in range(len(var)//2):
				if var[2*i][1:] == subjects[ID]:
					arc.append(var[2*i+1])
		subjectsID.write('\n'.join(arc))	
	return(queryID)	#Devolver la lista con los nombres de las querys para generar los archivos de las siguientes funciones con los mismos nombres.






