#!/usr/bin/env python
# encoding: utf-8

# script para parsear la base de datos prosite presentes en los archivos
# prosite.doc y prosite.dat utilizando el modulo Biopython

from Bio.ExPASy import Prosite 
import re

#PROSITE - PARSEO
def Parseo_dat(): #Parseo de la base de datos de prosite.
	handle = open("prosite.dat","r")
	records = Prosite.parse(handle)
	result = open("parseo_prosite","w") #generar archivo en el que introducir el resultado del parseo con su correspodiente cabecera:
	cabecera = 	str('**NAME**'+'\t'+'**ACCESSION**'+'\t'+'**DESCRIPTION**'+'\t'+'**PATTERN**'+'\n')
	result.write(cabecera) #introducir cabecera en el archivo de resultados
	for record in records:
		n=record.name
		a=record.accession
		d=record.description
		p=record.pattern
		resultado=str(n+'\t'+a+'\t'+'\t'+d+'\t'+p+'\n') #introducir los valores indicados en la cabecera separados por tabulador
		result.write(resultado)
	result.close()

#BÚSQUEDA DE PATRONES
def Patterns(sequence_file):
	salida = open(sequence_file+'_pat.txt','w') #abrir un archivo para cada query en el que introducir los patrones encontrados.
	s = open(sequence_file,'r') #Abrir archivo de cada query con los hits de blast.
	s = s.read()
	sequence = s.split('\n')
	#Recorrer el archivo de hits de blastp.
	for seq in range(len(sequence)//2): #secuencia: sequence[2*seq+1]
		ID = ("\nsubjectID:\t"+sequence[2*seq]+"\n")
		salida.write(ID) #escribuir en el archivo de patrones el ID del subject
		pa = open('parseo_prosite','r') #abrir y recorrer la base de datos parseada de prosite
		pa = pa.read()
		pattern = pa.split('\n') 
		for pat in pattern[1:]:
			if pat != "": #ignorar listas vacías
				pat = pat.split('\t')
				if len(pat[4]) != 0: #si hay patron se cambia el formato de prosite para que lo reconozca re
					p = pat[4]
					p=p.replace(".","")
					p=p.replace("<","^")
					p=p.replace("-","")
					p=p.replace("x",".")
					p=p.replace("{","[^")
					p=p.replace("}","]")
					p=p.replace("(","{")
					p=p.replace(")","}")
					p=p.replace(">","$")
					if re.search(p,sequence[2*seq+1]): #si encuentra coincidencia del patrón con la secuencia hit se añade la informacion al archivo de resultados
						output = (sequence[2*seq]+'\t'+pat[0]+'\t'+pat[1]+'\t'+pat[2]+'\t'+pat[3]+'\t'+pat[4]+'\n')
						sitios = []
						for match in re.finditer(p,sequence[2*seq+1]): #con finditer contamos el número de veces que aparece cada patrón en la secuencia
							start = match.start()
							end = match.end()
							posicion = (str(start)+'->'+str(end)) #la posición de los aminoácidos que comprende el patrón
							sitios.append(posicion)
						number = len(sitios) #número de veces que aparece
						output = ('\n\t'+"name: "+pat[0]+'\n\t'+"accesion: "+pat[1]+'\n\t'+"description: "+pat[3]+'\n\t'+"pattern: "+pat[4]+'\n\t'+"number of times: "+str(number)+'\n\t'+"positions: "+str(sitios)+'\n')
						salida.write(output) #introducir los valores en el archivo de resultados.
	salida.close()






