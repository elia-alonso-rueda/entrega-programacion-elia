#!/usr/bin/env python
# encoding: utf-8

#IMPORT DE TODO LO NECESARIO PARA EJECUTAR EL PROGRAMA
import os
import sys
import shutil
from subprocess import Popen, PIPE, call
from Bio import Seq
from Bio import SeqIO
from Bio.ExPASy import Prosite
import re

#IMPORT DE LOS MÓDULOS QUE COMPONEN EL PAQUETE
import BLAST
import MUSCLE
import PROSITE

#AYUDA
#Dar opción al usuario de leer la ayuda o ejecutar el programa directamente.
call("clear")
ayuda = input("Bienvenido/a.\nSoftware desarrollado por Elia Alonso Rueda para la entrega final de la asignatura Programación para la Bioinformática.\n\n¿Desea leer a la ayuda [predeterminado], o prefiere acceder directamente al programa [X]? >> ")
if ayuda.upper() != "X":
	call('clear')
	print("\nBienvenido/a a la ayuda.\n\n--> Con la ejecución de este programa se llevarán a cabo las siguientes acciones:")
	print("\t1. BLASTP. Se realizará un BlastP frente a las secuencias de proteínas de una base de datos genbank a partir de una o varias proteínas query. El usuario proporcionará estos dos archivos*. Se mostrarán los resultados del BlastP en pantalla y el usuario podrá filtrarlos introduciendo los valores de cobertura, porcentaje de identidad y e-value de interés.")
	print("\t2. ÁRBOLES. Con los hits obtenidos de BlastP, se alinearán las secuencias y se generará un árbol filogenético Neighbor-Joining (NJ) para cada una de las proteínas query.")
	print("\t3. PATRONES. Búsqueda de dominios de la base de datos PROSITE (archivo prosite.dat propocionado junto con este programa) entre los hits obtenidos de BlastP.\n")
	print("*Se proporciona un archivo genbank (genbank.gbff) y otro de proteínas query (query.fasta), por si el usuario prefiere usarlos en lugar de introducir los suyos.")
	print("*CUIDADO: Si va a utilizar sus propios archivos, asegúrese de que tanto la base de datos genbank como el archivo de proteínas query que introduce tengan un formato correcto (.gbff y .fasta, respectivamente). También es importante asegurarse de que estos dos archivos se encuentran en el mismo directorio que los módulos del paquete.")
	print("\n--> Los archivos generados con los resultados se almacenán dentro de la carpeta RESULTS, que se organizará en 3 subcarpetas:")
	print("\t1. BLASTP: Se almacenará un archivo con todos los resultados del BlastP sin filtrar (blast_result) y los archivos generados después de filtrar para cada query.")
	print("\t2. TREES: Se almacenarán los archivos de los árboles filogenéticos NJ generados con formato .tree.")
	print("\t3. PATTERNS: Se almacenarán los archivos de los patrones PROSITE encontrados en cada una de las proteínas query con formato .txt.\n")
	print("\nEste programa está desarrollado en forma de paquete. Con el script main.py se llevarán a cabo todas las acciones indicadas anteriormente (módulos) ejecutando secuencialmente el código.")
	#Una vez mostrada la ayuda, dar opción al usuario de ejecutar el programa o salir de él.
	ejecucion = input("\n\n¿Desea ejecutar el programa [predeterminado] o prefiere salir [X]? >> ")
	if ejecucion.upper() == "X":
		call('clear')
		print("\nHa escogido salir del programa. ¡Hasta pronto!")
		sys.exit()

#EJECUCIÓN DEL PROGRAMA
#Borrar todo lo mostrado anteriormente para ejecutar el programa en una pantalla limpia.
call('clear')
print("\t\t~~ EJECUCIÓN DEL PROGRAMA ~~")
#cwd = current work directory. 
cwd = os.getcwd()
#Borrar carpeta RESULTS preexistente de una ejecución anterior y generar una nueva para almacenar los resultados
if os.path.isdir(cwd+"/RESULTS"):
	shutil.rmtree("RESULTS")
os.mkdir("RESULTS")

#BLAST
archivo_parseo = input("Introduzca el nombre del documento de la base de datos. (Si prefiere utilizar el proporcionado por el programa, escriba: genbank.gbff): ")
archivo_query = input("Introduzca el nombre del documento de proteínas query que desea utilizar. (Si prefiere utilizar el proporcionado por el programa, escriba: query.fasta): ")
print("\n... REALIZANDO BLASTP ...\n")
#Parte I. Parseo de la base de datos genbank introducida por el usuario.
BLAST.Parseo_blast(archivo_parseo)
#Parte II. Blast.
BLAST.Blast(archivo_query)
#Parte III. Filtro de los datos según los valores introducidos por el usuario.
QuerysID=BLAST.Filtro()

#MUSCLE
print("\n... GENERANDO ÁRBOLES NJ ...")
for query in QuerysID:
	#Parte I. Alineamiento.
	MUSCLE.Align(query)
	#Parte II. Creación de los árboles.
	MUSCLE.Tree(query)

#PROSITE
print("\n... BUSCANDO PATRONES ...")
#Parte I. Parseo de la base de datos de PROSITE.
PROSITE.Parseo_dat()
#Parte II. Búsqueda de los patrones entre las secuencias subject obtenidas para cada query
for query in QuerysID:
	PROSITE.Patterns(query)

#Borrado y organización en diferentes directorios de los archivos generados durante la ejecución.
os.remove('subject')
os.remove('f')
os.remove('parseo_prosite')
#Crear carpetas para almacenar los datos obtenidos de BLAST, MUSCLE y PROSITE.
os.mkdir("1.BLASTP")
os.mkdir("2.TREES")
os.mkdir("3.PATTERNS")
#Guardar los resultados de BLAST, MUSCLE y PROSITE en sus correspondientes carpetas.
for query in QuerysID:
	call(["mv",query,"1.BLASTP"])
	Popen(["mv",query+".tree","2.TREES"],stderr=PIPE)
	call(["mv",query+"_pat.txt","3.PATTERNS"])
shutil.move('blast_result',"1.BLASTP")
#Montar la carpeta RESULTS.
shutil.move("1.BLASTP","RESULTS")
shutil.move("2.TREES","RESULTS")
shutil.move("3.PATTERNS","RESULTS")
#Notificar al usuario cuando termine de ejecutarse el programa.
print("\nPrograma realizado con éxito.\n¡Hasta pronto!")
